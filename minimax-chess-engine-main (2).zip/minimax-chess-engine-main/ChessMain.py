import os
import math
import pygame as p
import ChessEngine
import nhom4

WIDTH = HEIGHT = 512
MOVE_LOG_PANEL_WIDTH = 290
MOVE_LOG_PANEL_HEIGHT = HEIGHT
DIMENSION = 8
SQ_SIZE = HEIGHT // DIMENSION
MAX_FPS = 240
IMAGES = {}
PIECE_TO_FILENAME = {
    "wp": "white_pawn",
    "wR": "white_rook",
    "wN": "white_knight",
    "wB": "white_bishop",
    "wQ": "white_queen",
    "wK": "white_king",
    "bp": "black_pawn",
    "bR": "black_rook",
    "bN": "black_knight",
    "bB": "black_bishop",
    "bQ": "black_queen",
    "bK": "black_king",
}

def load_images():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    for piece, filename in PIECE_TO_FILENAME.items():
        IMAGES[piece] = p.transform.scale(
            p.image.load(os.path.join(BASE_DIR, "images", filename + ".png")),
            (SQ_SIZE, SQ_SIZE)
        )
def main():
    p.init()
    screen = p.display.set_mode((WIDTH + MOVE_LOG_PANEL_WIDTH, HEIGHT))
    clock = p.time.Clock()
    load_images()                        # ← load ảnh trước
    difficulty = difficultyScreen(screen) # ← chọn độ khó
    nhom4.setDifficulty(difficulty)
    print(f"Difficulty: {difficulty.upper()}")
    screen.fill(p.Color("white"))        # ← sau khi chọn xong mới init game
    gs = ChessEngine.GameState()
    validMoves = gs.getValidMoves()
    moveMade = False
    animate = False
    gameOver = False
    playerOne = True
    playerTwo = False
    sqSelected = ()
    playerClicks = []
    running = True
    while running:
        humanTurn = (gs.whiteToMove and playerOne) or (not gs.whiteToMove and playerTwo)
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            elif e.type == p.MOUSEBUTTONDOWN:
                if not gameOver and humanTurn:
                    location = p.mouse.get_pos()
                    col = location[0]//SQ_SIZE
                    row = location[1]//SQ_SIZE
                    if sqSelected == (row, col) or col >= 8:
                        sqSelected = ()
                        playerClicks = []
                    else:
                        sqSelected = (row, col)
                        playerClicks.append(sqSelected)
                    if len(playerClicks) == 2:
                        move = ChessEngine.Move(playerClicks[0], playerClicks[1], gs.board)
                        if move in validMoves:
                            move = validMoves[validMoves.index(move)]
                            gs.makeMove(move)
                            moveMade = True
                            animate = True
                            sqSelected = ()
                            playerClicks = []
                            print(move.getChessNotation())
                        else:
                            playerClicks = [sqSelected]
            elif e.type == p.KEYDOWN:
                if e.key == p.K_z:
                    gs.undoMove()
                    moveMade = True
                    animate = False
                    gameOver = False
                    playerOne = True
                    playerTwo = True
                elif e.key == p.K_r:
                    gs = ChessEngine.GameState()
                    validMoves = gs.getValidMoves()
                    moveMade = False
                    animate = False
                    gameOver = False
                    playerOne = True
                    playerTwo = True
                    sqSelected = ()
                    playerClicks = []
                elif e.key == p.K_q:
                    playerOne = False
                    playerTwo = True
                elif e.key == p.K_e:
                    playerOne = True
                    playerTwo = False

        if moveMade:
            if animate:
                animateMove(gs.moveLog[-1], screen, gs.board, clock)
            validMoves = gs.getValidMoves()
            moveMade = False
            animate = False

        ''' AI move finder '''
        if not gameOver and not humanTurn:
            AIMove = nhom4.findBestMoveMinimax(gs, validMoves)
            #AIMove = ChienKoNgu.findRandomMove(validMoves)
            if AIMove is None:   #when begin the game
                AIMove = nhom4.findRandomMove(validMoves)
            gs.makeMove(AIMove)
            moveMade = True
            animate = True
            print(AIMove.getChessNotation())

        drawGameState(screen, gs, validMoves, sqSelected)

        if gs.checkMate or gs.staleMate:
            gameOver = True
            if gs.staleMate:
                gameOver = True
                drawEndGameText(screen, "DRAW")
            else:
                if gs.whiteToMove:
                    drawEndGameText(screen, "BLACK WIN")
                else:
                    drawEndGameText(screen, "WHITE WIN")


        clock.tick(MAX_FPS)
        p.display.flip()

def highlightMove(screen, gs, validMoves, sqSelected):
    sq = p.Surface((SQ_SIZE, SQ_SIZE))
    sq.set_alpha(100)
    if sqSelected != ():
        r, c = sqSelected
        if gs.board[r][c][0] == ('w' if gs.whiteToMove else 'b'): #sqSelected is a piece that can be moved
            #highlight selected square
            sq.fill(p.Color("blue"))
            screen.blit(sq, (c * SQ_SIZE, r * SQ_SIZE))
            #highlight validmoves
            sq.fill(p.Color("cyan"))
            for move in validMoves:
                if move.startRow == r and move.startCol == c:
                    screen.blit(sq, (move.endCol * SQ_SIZE, move.endRow * SQ_SIZE))

    if gs.inCheck:
        if gs.whiteToMove:
            sq.fill(p.Color("red"))
            screen.blit(sq, (gs.whiteKingLocate[1] * SQ_SIZE, gs.whiteKingLocate[0] * SQ_SIZE))
        else:
            sq.fill(p.Color("red"))
            screen.blit(sq, (gs.blackKingLocate[1] * SQ_SIZE, gs.blackKingLocate[0] * SQ_SIZE))
    
    if len(gs.moveLog) != 0:
        sq.fill(p.Color("yellow"))
        screen.blit(sq, (gs.moveLog[-1].startCol * SQ_SIZE, gs.moveLog[-1].startRow * SQ_SIZE))
        screen.blit(sq, (gs.moveLog[-1].endCol * SQ_SIZE, gs.moveLog[-1].endRow * SQ_SIZE))


def animateMove(move, screen, board, clock):
    colors = [p.Color("white"), p.Color("grey")]
    dR = move.endRow - move.startRow
    dC = move.endCol - move.startCol
    sqDistance = math.sqrt(abs(move.endRow - move.startRow)*abs(move.endRow - move.startRow) +
                           abs(move.endCol - move.startCol)*abs(move.endCol - move.startCol))
    sqDistance = int(sqDistance)
    framesPerSquare = 12 // sqDistance
    frameCount = (abs(dR) + abs(dC)) * framesPerSquare
    for frame in range(frameCount + 1):
        r, c = (move.startRow + dR*frame/frameCount, move.startCol + dC*frame/frameCount)
        drawBoard(screen)
        drawPieces(screen, board)
        color = colors[(move.endRow + move.endCol) % 2]
        endSquare = p.Rect(move.endCol*SQ_SIZE, move.endRow*SQ_SIZE, SQ_SIZE, SQ_SIZE)
        p.draw.rect(screen, color, endSquare)
        if move.pieceCaptured != "--":
            if move.isEnpassantMove:
                enPassantRow = (move.endRow + 1) if move.pieceCaptured[0] == 'b' else (move.endRow - 1)
                endSquare = p.Rect(move.endCol*SQ_SIZE, enPassantRow*SQ_SIZE, SQ_SIZE, SQ_SIZE)
            screen.blit(IMAGES[move.pieceCaptured], endSquare)
        if move.pieceMoved != "--":
            screen.blit(IMAGES[move.pieceMoved], p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))
        p.display.flip()
        clock.tick(144)

def drawGameState(screen, gs, validMoves, sqSelected):
    drawBoard(screen)
    highlightMove(screen, gs, validMoves, sqSelected)
    drawPieces(screen, gs.board)
    drawMoveLog(screen, gs)

def drawBoard(screen):
    colors = [p.Color("#EAEDD1"), p.Color("#769556")]
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color = colors[((r + c) % 2)]
            p.draw.rect(screen, color, p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))

def drawPieces(screen, board):
    for row in range(DIMENSION):
        for col in range(DIMENSION):
            piece = board[row][col]
            if piece != "--":
                screen.blit(IMAGES[piece], p.Rect(col*SQ_SIZE, row*SQ_SIZE, SQ_SIZE, SQ_SIZE))

def drawEndGameText(screen, text):
    font = p.font.SysFont("Verdana", 32, True, False)
    textObject = font.render(text, False, p.Color("black"))
    textLocation = p.Rect(0, 0, WIDTH, HEIGHT).move(WIDTH/2 - textObject.get_width()/2, HEIGHT/2 - textObject.get_height()/2)
    screen.blit(textObject, textLocation)
    textObject = font.render(text, False, p.Color("red"))
    screen.blit(textObject, textLocation.move(2, 2))

def drawMoveLog(screen, gs):
    moveLogRect = p.Rect(WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
    p.draw.rect(screen, p.Color(30, 30, 30), moveLogRect)

    # Tiêu đề
    font_title = p.font.SysFont("Verdana", 14, True, False)
    title = font_title.render("Move Log", True, p.Color("white"))
    screen.blit(title, moveLogRect.move(10, 8))

    # Vẽ đường kẻ dưới tiêu đề
    p.draw.line(screen, p.Color(80, 80, 80),
                (WIDTH, 30), (WIDTH + MOVE_LOG_PANEL_WIDTH, 30), 1)

    moveLog = gs.moveLog
    font = p.font.SysFont("Consolas", 14, False, False)
    padding = 10
    textY = 38
    row_height = 22

    for i in range(0, len(moveLog), 2):
        move_num = str(i // 2 + 1) + "."

        # Số thứ tự — màu vàng nhạt
        num_surface = font.render(move_num, True, p.Color(180, 180, 100))
        screen.blit(num_surface, moveLogRect.move(padding, textY))

        # Nước trắng
        white_move = str(moveLog[i])
        w_surface = font.render(white_move, True, p.Color("white"))
        screen.blit(w_surface, moveLogRect.move(padding + 35, textY))

        # Nước đen (nếu có)
        if i + 1 < len(moveLog):
            black_move = str(moveLog[i + 1])
            b_surface = font.render(black_move, True, p.Color(180, 180, 180))
            screen.blit(b_surface, moveLogRect.move(padding + 145, textY))

        textY += row_height

        # Nếu tràn ra ngoài panel thì dừng
        if textY > MOVE_LOG_PANEL_HEIGHT - row_height:
            break
def difficultyScreen(screen):
    """Màn hình chọn độ khó trước khi vào game"""
    screen.fill(p.Color(30, 30, 30))
    font_title = p.font.SysFont("Verdana", 28, True, False)
    font_btn   = p.font.SysFont("Verdana", 18, True, False)
    font_sub   = p.font.SysFont("Verdana", 12, False, False)

    title = font_title.render("Select Difficulty", True, p.Color("white"))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 60))

    # Thông tin mỗi cấp độ
    levels = [
        {
            "label": "EASY",
            "color": (80, 160, 80),
            "hover": (100, 200, 100),
            "key": "easy",
            "lines": ["Depth: 2", "Thỉnh thoảng đi sai", "Move: Ngẫu nhiên"]
        },
        {
            "label": "MEDIUM",
            "color": (180, 140, 40),
            "hover": (220, 170, 50),
            "key": "medium",
            "lines": ["Depth: 3", "Vị trí + trung tâm", "Nhập thành: Có"]
        },
        {
            "label": "HARD",
            "color": (180, 50, 50),
            "hover": (220, 70, 70),
            "key": "hard",
            "lines": ["Depth: 4", "MVV-LVA + chiếu", "Nhập thành: Bắt buộc"]
        },
    ]

    btn_w, btn_h = 160, 180
    gap = 30
    total_w = 3 * btn_w + 2 * gap
    start_x = (WIDTH + MOVE_LOG_PANEL_WIDTH) // 2 - total_w // 2
    btn_y = 150

    rects = []
    for i, lv in enumerate(levels):
        rect = p.Rect(start_x + i * (btn_w + gap), btn_y, btn_w, btn_h)
        rects.append(rect)

    selected = None
    while selected is None:
        mouse_pos = p.mouse.get_pos()
        for e in p.event.get():
            if e.type == p.QUIT:
                p.quit()
                exit()
            if e.type == p.MOUSEBUTTONDOWN:
                for i, rect in enumerate(rects):
                    if rect.collidepoint(mouse_pos):
                        selected = levels[i]["key"]

        screen.fill(p.Color(30, 30, 30))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 60))

        for i, lv in enumerate(levels):
            rect = rects[i]
            color = lv["hover"] if rect.collidepoint(mouse_pos) else lv["color"]
            p.draw.rect(screen, color, rect, border_radius=12)
            p.draw.rect(screen, p.Color("white"), rect, 2, border_radius=12)

            # Label
            btn_text = font_btn.render(lv["label"], True, p.Color("white"))
            screen.blit(btn_text, (rect.x + rect.w // 2 - btn_text.get_width() // 2, rect.y + 15))

            # Sub info
            for j, line in enumerate(lv["lines"]):
                sub = font_sub.render(line, True, p.Color(230, 230, 230))
                screen.blit(sub, (rect.x + 10, rect.y + 60 + j * 22))

        p.display.flip()

    return selected
if __name__ == "__main__":
    main()